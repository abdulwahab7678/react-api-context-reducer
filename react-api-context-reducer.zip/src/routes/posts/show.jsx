export default function PostShow(){
    return(
        <div>
        hello world
    </div>
    )
    }
    
    